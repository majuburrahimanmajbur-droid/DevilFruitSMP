# DevilFruitSMP 1.1.0

A modular, original Devil Fruit-style SMP plugin for **Paper 1.21.x** with Java + Bedrock cross-play through **GeyserMC/Floodgate**.

## Cross-play architecture

The plugin is a normal Paper plugin. It does **not** use NMS, client mods, resource packs, or a second Bedrock gameplay implementation.

Geyser translates Bedrock player interactions into the normal server-side Bukkit/Paper events. The same `AbilityManager`, fruit data, cooldowns, damage, particles, sounds, targeting and GUI code therefore runs for both Java and Bedrock players.

Floodgate is optional at runtime. When present, the plugin detects Floodgate players reflectively and shows Bedrock control help; there is no compile-time Floodgate dependency.

### Default controls

| Input | Java | Bedrock |
|---|---|---|
| Right click / Use | Active 1 | Active 1 |
| Sneak + Right click / Use | Active 2 | Active 2 |
| Left click / Attack | Active 3 | Active 3 |

The mapping is configurable independently under `input.controls.java` and `input.controls.bedrock`, but both platforms call the same ability code. A small configurable debounce (`input.debounce-ms`) prevents duplicate casts when translated Geyser input produces more than one Bukkit event.

### Optional ability-item fallback

If you want abilities separated from ordinary combat, enable:

```yaml
input:
  require-ability-item: true
  ability-item:
    material: BLAZE_ROD
    name: "&dAbility Selector"
```

No client mod or resource pack is required. The item is only an optional server-side input gate; it does not create a second Bedrock gameplay system.

## GUI

`/fruit` uses standard Bukkit inventory/container APIs only. Bedrock players can open and use the same menus through Geyser's normal container translation.

## Build

Requirements:

- JDK 21
- Maven 3.9+
- Paper 1.21.x
- Geyser-Spigot for Bedrock cross-play
- Floodgate if you want Bedrock account integration

Run:

```bash
mvn clean package
```

The plugin JAR is created under `target/`.

## Commands

Players:

- `/roll`
- `/fruit`
- `/fruit info`
- `/fruit all`

Admins (`devilfruit.admin`):

- `/fruit give <player> <fruit>`
- `/fruit set <player> <fruit>`
- `/fruit resetroll <player>`
- `/fruit reload`

There is deliberately **no normal-player `/fruit remove` or `/fruit lose` command**.

## Fruit transfer

A fruit transfers only when Bukkit reports a player killer (`Player#getKiller`). Environmental deaths do not transfer fruits.

The transfer is performed in memory first, then both player records are saved immediately when configured. By default, `death.overwrite-killer-fruit` is `false`, preventing an existing fruit owner from being overwritten and avoiding accidental duplicate/ownership loss.

## Testing checklist

Test on a real Paper server with Geyser installed:

1. Java player uses `/roll` — exactly one fruit is assigned and persisted.
2. Bedrock player uses `/roll` — the same roll/data system is used.
3. Test all three inputs on Java and Bedrock for every fruit.
4. Test each ability with no nearby enemies; the ability must still cast.
5. Put a valid enemy inside each AoE and verify automatic damage/effects.
6. Verify action-bar cooldowns and repeated-click prevention.
7. Open `/fruit` and `/fruit all` from both platforms.
8. Kill a fruit owner with another player and verify transfer.
9. Kill a fruit owner with fall/lava/fire/drowning/void/explosion/etc. and verify no transfer.
10. Restart the server and verify fruit ownership remains unchanged.

Because actual Bedrock clients and a running Geyser server are not available in this source-generation environment, cross-platform behavior is implemented against Geyser's normal Bukkit event translation but must be validated on a live Geyser + Bedrock test server before production deployment.
