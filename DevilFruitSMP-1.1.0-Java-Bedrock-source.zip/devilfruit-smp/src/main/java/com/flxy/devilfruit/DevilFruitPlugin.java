package com.flxy.devilfruit;

import com.flxy.devilfruit.ability.AbilityManager; import com.flxy.devilfruit.command.FruitCommand; import com.flxy.devilfruit.data.DataStore; import com.flxy.devilfruit.fruit.FruitType; import com.flxy.devilfruit.listener.GameListener;
import org.bukkit.*; import org.bukkit.entity.Player; import org.bukkit.plugin.java.JavaPlugin;
import java.util.*;

public class DevilFruitPlugin extends JavaPlugin {
 public DataStore data; public AbilityManager abilities;
 @Override public void onEnable(){saveDefaultConfig();data=new DataStore(this);abilities=new AbilityManager(this);FruitCommand commands=new FruitCommand(this);getCommand("roll").setExecutor(commands);getCommand("roll").setTabCompleter(commands);getCommand("fruit").setExecutor(commands);getCommand("fruit").setTabCompleter(commands);getServer().getPluginManager().registerEvents(new GameListener(this),this);getServer().getPluginManager().registerEvents(new com.flxy.devilfruit.gui.FruitGui(this),this);getServer().getScheduler().runTaskTimer(this,()->getOnlinePlayers().forEach(u->{var d=data.get(u.getUniqueId(),u.getName());if(d.fruit!=null)abilities.passive(u,d.fruit);}),20,20);getLogger().info("DevilFruitSMP enabled.");}
 @Override public void onDisable(){data.saveAll();}
 public double cfg(String path,double def){return getConfig().getDouble(path,def);}
 public boolean canDamage(Player a,Player b){if(getConfig().getStringList("pvp.safe-worlds").contains(b.getWorld().getName()))return false;if(inSafeZone(b))return false;if(!getConfig().getBoolean("pvp.friendly-fire",false)){var ta=a.getScoreboard().getEntryTeam(a.getName());var tb=b.getScoreboard().getEntryTeam(b.getName());if(ta!=null&&ta.equals(tb))return false;}return true;}
 private boolean inSafeZone(Player p){for(String s:getConfig().getStringList("pvp.safe-zones")){String[] x=s.split(",");if(x.length!=5)continue;try{if(!x[0].equals(p.getWorld().getName()))continue;double dx=p.getX()-Double.parseDouble(x[1]),dy=p.getY()-Double.parseDouble(x[2]),dz=p.getZ()-Double.parseDouble(x[3]),r=Double.parseDouble(x[4]);if(dx*dx+dy*dy+dz*dz<=r*r)return true;}catch(NumberFormatException ignored){}}return false;}
 public FruitType roll(){List<String> keys=new ArrayList<>();for(String k:getConfig().getConfigurationSection("fruit-roll.chances").getKeys(false)){int n=Math.max(0,getConfig().getInt("fruit-roll.chances."+k));for(int i=0;i<n;i++)keys.add(k);}if(keys.isEmpty())return FruitType.MAGMA;String k=keys.get(new Random().nextInt(keys.size()));return FruitType.parse(k);}
}
