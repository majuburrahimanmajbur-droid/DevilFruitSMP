package com.flxy.devilfruit.util;

import org.bukkit.entity.Player;

import java.lang.reflect.Method;
import java.util.UUID;

/** Optional Floodgate detection. The plugin does not link against Floodgate at compile time. */
public final class PlatformUtil {
    private static final String FLOODGATE_API = "org.geysermc.floodgate.api.FloodgateApi";
    private static Method instanceMethod;
    private static Method isFloodgatePlayer;
    private static boolean lookedUp;

    private PlatformUtil() {}

    public static boolean isBedrock(Player player) {
        try {
            if (!lookedUp) discover();
            if (instanceMethod == null || isFloodgatePlayer == null) return false;
            Object api = instanceMethod.invoke(null);
            Object result = isFloodgatePlayer.invoke(api, player.getUniqueId());
            return result instanceof Boolean b && b;
        } catch (ReflectiveOperationException | RuntimeException ignored) {
            return false;
        }
    }

    private static void discover() {
        lookedUp = true;
        try {
            Class<?> api = Class.forName(FLOODGATE_API);
            instanceMethod = api.getMethod("getInstance");
            isFloodgatePlayer = api.getMethod("isFloodgatePlayer", UUID.class);
        } catch (ReflectiveOperationException ignored) {
            instanceMethod = null;
            isFloodgatePlayer = null;
        }
    }
}
