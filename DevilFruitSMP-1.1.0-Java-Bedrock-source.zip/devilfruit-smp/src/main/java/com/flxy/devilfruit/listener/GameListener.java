package com.flxy.devilfruit.listener;

import com.flxy.devilfruit.DevilFruitPlugin;
import com.flxy.devilfruit.data.PlayerData;
import com.flxy.devilfruit.fruit.FruitType;
import com.flxy.devilfruit.util.PlatformUtil;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerAnimationEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Cross-platform input bridge.
 *
 * Geyser translates Bedrock Use/Attack input into the normal Bukkit/Paper events,
 * so Java and Bedrock use the exact same AbilityManager and gameplay code.
 */
public final class GameListener implements Listener {
    private final DevilFruitPlugin plugin;
    private final Map<UUID, Long> lastInput = new ConcurrentHashMap<>();

    public GameListener(DevilFruitPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;

        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK
                && action != Action.LEFT_CLICK_AIR && action != Action.LEFT_CLICK_BLOCK) return;

        Player player = event.getPlayer();
        if (!isAbilityInputEnabled(player)) return;

        if (action == Action.RIGHT_CLICK_AIR || action == Action.RIGHT_CLICK_BLOCK) {
            trigger(player, "right-click", player.isSneaking());
        } else {
            trigger(player, "left-click", false);
        }
    }

    /**
     * Attack input is also observed through PlayerAnimationEvent. This catches
     * left-click/attack input consistently when no block interaction event is emitted.
     */
    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = false)
    public void onAnimation(PlayerAnimationEvent event) {
        Player player = event.getPlayer();
        if (!isAbilityInputEnabled(player)) return;
        trigger(player, "left-click", false);
    }

    private boolean isAbilityInputEnabled(Player player) {
        if (!plugin.getConfig().getBoolean("input.enabled", true)) return false;
        if (!plugin.getConfig().getBoolean("input.require-ability-item", false)) return true;

        ItemStack item = player.getInventory().getItemInMainHand();
        Material required = Material.matchMaterial(
                plugin.getConfig().getString("input.ability-item.material", "BLAZE_ROD"));
        return required != null && item.getType() == required;
    }

    private void trigger(Player player, String input, boolean sneaking) {
        long now = System.currentTimeMillis();
        long debounce = Math.max(0L, plugin.getConfig().getLong("input.debounce-ms", 120L));
        Long previous = lastInput.get(player.getUniqueId());
        if (previous != null && now - previous < debounce) return;
        lastInput.put(player.getUniqueId(), now);

        PlayerData data = plugin.data.get(player.getUniqueId(), player.getName());
        if (data.fruit == null) return;

        String platform = PlatformUtil.isBedrock(player) ? "bedrock" : "java";
        String configuredInput = sneaking ? "sneak-right-click" : input;
        int configuredAbility = plugin.getConfig().getInt(
                "input.controls." + platform + "." + configuredInput, defaultAbility(configuredInput));

        // Config uses human-friendly 1/2/3. Internally AbilityManager uses 0/1/2.
        if (configuredAbility < 1 || configuredAbility > 3) return;
        plugin.abilities.cast(player, data.fruit, configuredAbility - 1);
    }

    private int defaultAbility(String input) {
        return switch (input) {
            case "right-click" -> 1;
            case "sneak-right-click" -> 2;
            case "left-click" -> 3;
            default -> 0;
        };
    }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        PlayerData data = plugin.data.get(player.getUniqueId(), player.getName());
        data.name = player.getName();
        plugin.data.save(data);

        if (PlatformUtil.isBedrock(player)) {
            player.sendActionBar(ChatColor.AQUA + "Bedrock: " + ChatColor.WHITE
                    + "Use = A1  |  Sneak + Use = A2  |  Attack = A3");
        }
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        plugin.data.save(plugin.data.get(event.getPlayer().getUniqueId(), event.getPlayer().getName()));
        plugin.abilities.cooldowns.clear(event.getPlayer().getUniqueId());
        lastInput.remove(event.getPlayer().getUniqueId());
    }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getEntity();
        Player killer = victim.getKiller();
        PlayerData victimData = plugin.data.get(victim.getUniqueId(), victim.getName());

        // Player#getKiller is the authoritative Bukkit signal for a confirmed player kill.
        // If it is null, this is not transferred: fall, lava, fire, drowning, void,
        // explosions, /kill and other non-player causes remain untouched.
        if (victimData.fruit == null || killer == null
                || !plugin.getConfig().getBoolean("death.transfer-only-on-player-kill", true)) return;

        PlayerData killerData = plugin.data.get(killer.getUniqueId(), killer.getName());
        FruitType moved = victimData.fruit;

        // Do not overwrite an existing owner by default. This guarantees that a valid
        // transfer cannot accidentally create duplicate fruit ownership.
        if (killerData.fruit != null && !plugin.getConfig().getBoolean("death.overwrite-killer-fruit", false)) {
            killer.sendMessage(ChatColor.RED + "You already own " + killerData.fruit.display
                    + ". The defeated player's fruit was not transferred.");
            return;
        }

        victimData.fruit = null;
        killerData.fruit = moved;
        killerData.hasRolled = true;

        if (plugin.getConfig().getBoolean("death.save-immediately", true)) {
            plugin.data.save(victimData);
            plugin.data.save(killerData);
        }

        killer.sendMessage(ChatColor.GREEN + "☠ You claimed " + ChatColor.WHITE + moved.display
                + ChatColor.GREEN + " from " + ChatColor.WHITE + victim.getName() + ChatColor.GREEN + "!");
        victim.sendMessage(ChatColor.RED + "☠ Your " + ChatColor.WHITE + moved.display
                + ChatColor.RED + " was claimed by " + ChatColor.WHITE + killer.getName() + ChatColor.RED + ".");
    }
}
