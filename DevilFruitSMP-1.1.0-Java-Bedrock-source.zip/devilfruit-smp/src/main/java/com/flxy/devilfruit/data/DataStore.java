package com.flxy.devilfruit.data;
import com.flxy.devilfruit.DevilFruitPlugin;
import com.flxy.devilfruit.fruit.FruitType;
import org.bukkit.configuration.file.YamlConfiguration;
import java.io.File; import java.io.IOException; import java.util.*;
public class DataStore {
 private final DevilFruitPlugin plugin; private final File file; private final YamlConfiguration yml; private final Map<UUID,PlayerData> cache=new HashMap<>();
 public DataStore(DevilFruitPlugin p){plugin=p; file=new File(p.getDataFolder(),"players.yml"); if(!file.exists())try{p.getDataFolder().mkdirs();file.createNewFile();}catch(IOException e){throw new RuntimeException(e);} yml=YamlConfiguration.loadConfiguration(file); load();}
 private void load(){for(String k:yml.getKeys(false)){try{UUID u=UUID.fromString(k); String f=yml.getString(k+".fruit"); cache.put(u,new PlayerData(u,yml.getString(k+".name","Unknown"),yml.getBoolean(k+".has-rolled"),f==null?null:FruitType.parse(f),yml.getInt(k+".mastery"),yml.getBoolean(k+".awakened")));}catch(Exception ignored){}}}
 public PlayerData get(UUID u,String name){return cache.computeIfAbsent(u,x->new PlayerData(u,name,false,null,0,false));}
 public void save(PlayerData d){String p=d.uuid.toString();yml.set(p+".name",d.name);yml.set(p+".has-rolled",d.hasRolled);yml.set(p+".fruit",d.fruit==null?null:d.fruit.name());yml.set(p+".mastery",d.mastery);yml.set(p+".awakened",d.awakened); try{yml.save(file);}catch(IOException e){plugin.getLogger().severe("Could not save player data: "+e.getMessage());}}
 public void saveAll(){cache.values().forEach(this::save);}
 public Collection<PlayerData> all(){return cache.values();}
}
