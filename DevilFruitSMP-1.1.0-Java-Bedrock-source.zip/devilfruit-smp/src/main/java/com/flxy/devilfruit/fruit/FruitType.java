package com.flxy.devilfruit.fruit;

import java.util.*;

public enum FruitType {
 MAGMA("Magma Fruit","Legendary","Magma Body","Magma Shot","Lava Burst","Volcanic Slam","🌋"),
 VOLT("Volt Fruit","Legendary","Static Body","Lightning Dash","Thunder Strike","Chain Lightning","⚡"),
 FROST("Frost Fruit","Epic","Frozen Soul","Ice Spike","Frost Wall","Blizzard","❄"),
 GALE("Gale Fruit","Epic","Feather Step","Wind Dash","Air Cannon","Tornado","🌪"),
 VOID("Void Fruit","Mythic","Void Walker","Void Blink","Gravity Pull","Void Zone","🌑"),
 INFERNO("Inferno Fruit","Legendary","Ember Heart","Flame Burst","Flame Dash","Inferno Ring","🔥"),
 VINE("Vine Fruit","Rare","Nature's Blessing","Vine Whip","Root Trap","Nature Heal","🌿"),
 CRYSTAL("Crystal Fruit","Epic","Crystal Skin","Crystal Shot","Crystal Shield","Crystal Prison","💎"),
 TIDAL("Tidal Fruit","Rare","Ocean Soul","Water Bullet","Tidal Wave","Whirlpool","🌊"),
 SOLAR("Solar Fruit","Mythic","Solar Energy","Solar Beam","Flash Step","Solar Nova","☀");
 public final String display, rarity, passive, a1, a2, a3, icon;
 FruitType(String display,String rarity,String passive,String a1,String a2,String a3,String icon){this.display=display;this.rarity=rarity;this.passive=passive;this.a1=a1;this.a2=a2;this.a3=a3;this.icon=icon;}
 public static FruitType parse(String s){for(FruitType f:values()) if(f.name().equalsIgnoreCase(s)||f.display.replace(" Fruit","").equalsIgnoreCase(s)) return f; return null;}
 public List<String> abilities(){return List.of(a1,a2,a3);}
}
