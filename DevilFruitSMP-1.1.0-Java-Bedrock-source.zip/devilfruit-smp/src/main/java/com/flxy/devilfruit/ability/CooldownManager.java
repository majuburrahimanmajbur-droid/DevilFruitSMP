package com.flxy.devilfruit.ability;
import java.util.*;
public class CooldownManager { private final Map<UUID,Map<String,Long>> map=new HashMap<>(); public long remaining(UUID u,String key){long end=map.getOrDefault(u,Map.of()).getOrDefault(key,0L);return Math.max(0,end-System.currentTimeMillis());} public boolean ready(UUID u,String key){return remaining(u,key)<=0;} public void set(UUID u,String key,double seconds){map.computeIfAbsent(u,x->new HashMap<>()).put(key,System.currentTimeMillis()+(long)(seconds*1000));} public void clear(UUID u){map.remove(u);} }
