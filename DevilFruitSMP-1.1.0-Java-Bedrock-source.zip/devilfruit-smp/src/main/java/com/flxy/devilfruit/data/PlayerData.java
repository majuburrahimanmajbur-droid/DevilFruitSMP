package com.flxy.devilfruit.data;
import com.flxy.devilfruit.fruit.FruitType;
import java.util.UUID;
public class PlayerData { public final UUID uuid; public String name; public boolean hasRolled; public FruitType fruit; public int mastery; public boolean awakened; public PlayerData(UUID u,String n,boolean r,FruitType f,int m,boolean a){uuid=u;name=n;hasRolled=r;fruit=f;mastery=m;awakened=a;} }
