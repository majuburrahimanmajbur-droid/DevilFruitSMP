package com.flxy.devilfruit.util;
import com.flxy.devilfruit.DevilFruitPlugin;
import org.bukkit.*; import org.bukkit.entity.*; import org.bukkit.potion.PotionEffect; import org.bukkit.potion.PotionEffectType; import org.bukkit.util.Vector;
import java.util.*;
public final class AbilityUtil {
 public static List<Player> enemies(DevilFruitPlugin p,Player user,double radius){List<Player> out=new ArrayList<>();for(Entity e:user.getNearbyEntities(radius,radius,radius))if(e instanceof Player t && !t.equals(user)&&p.canDamage(user,t))out.add(t);return out;}
 public static void damage(DevilFruitPlugin p,Player user,Player t,double dmg,double kb){if(dmg>0)t.damage(dmg,user);if(kb>0){Vector v=t.getLocation().toVector().subtract(user.getLocation().toVector()).normalize().multiply(kb).setY(Math.max(.25,kb*.45));t.setVelocity(v);}}
 public static void burst(Location l,Particle particle,Sound sound,int count){l.getWorld().spawnParticle(particle,l,count,.6,.6,.6,.05);l.getWorld().playSound(l,sound,1f,1f);}
 public static void line(Player p,Particle particle,Sound sound,double length){Location l=p.getEyeLocation();Vector d=l.getDirection().normalize();for(double x=0;x<=length;x+=.45){Location q=l.clone().add(d.clone().multiply(x));p.getWorld().spawnParticle(particle,q,3,0.08,0.08,0.08,0);}}
 public static void effect(Player t,PotionEffectType type,int ticks,int amp){t.addPotionEffect(new PotionEffect(type,ticks,amp,false,false,true));}
 public static void pull(Player user,Player t,double power){Vector v=user.getLocation().toVector().subtract(t.getLocation().toVector()).normalize().multiply(power).setY(.35);t.setVelocity(v);}
 private AbilityUtil(){}
}
